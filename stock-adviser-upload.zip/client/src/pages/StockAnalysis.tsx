import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { APP_TITLE, getLoginUrl } from "@/const";
import { Search, TrendingUp, Loader2, Home, PieChart } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function StockAnalysis() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [selectedStock, setSelectedStock] = useState<any>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  
  const [investmentHorizon, setInvestmentHorizon] = useState([12]); // months
  const [fundamentalTechnicalRatio, setFundamentalTechnicalRatio] = useState([50]); // 0-100
  const [age, setAge] = useState("");
  const [employmentStatus, setEmploymentStatus] = useState("");
  const [employmentSector, setEmploymentSector] = useState("");
  
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const utils = trpc.useUtils();

  const analyzeMutation = trpc.stocks.analyze.useMutation({
    onSuccess: (data) => {
      setAnalysisResult(data);
      setIsAnalyzing(false);
      toast.success("Analysis complete!");
    },
    onError: (error) => {
      toast.error("Analysis failed: " + error.message);
      setIsAnalyzing(false);
    },
  });

  const addToPortfolioMutation = trpc.portfolio.add.useMutation({
    onSuccess: () => {
      toast.success("Stock added to portfolio!");
    },
    onError: (error) => {
      toast.error("Failed to add to portfolio: " + error.message);
    },
  });

  const profileQuery = trpc.profile.get.useQuery();

  useEffect(() => {
    if (profileQuery.data && profileQuery.data !== null) {
      setAge(profileQuery.data.age?.toString() || "");
      setEmploymentStatus(profileQuery.data.employmentStatus || "");
      setEmploymentSector(profileQuery.data.employmentSector || "");
    }
  }, [profileQuery.data]);

  // Debounced autocomplete search
  useEffect(() => {
    const delayTimer = setTimeout(async () => {
      if (searchQuery.trim().length >= 2) {
        setIsSearching(true);
        try {
          const result = await utils.stocks.search.fetch({ keywords: searchQuery });
          setSearchResults(result);
          setShowDropdown(true);
        } catch (error: any) {
          console.error("Search error:", error);
          setSearchResults([]);
        }
        setIsSearching(false);
      } else {
        setSearchResults([]);
        setShowDropdown(false);
      }
    }, 500); // 500ms debounce

    return () => clearTimeout(delayTimer);
  }, [searchQuery]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = () => setShowDropdown(false);
    if (showDropdown) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [showDropdown]);

  const handleSelectStock = (stock: any) => {
    setSelectedStock(stock);
    setSearchQuery(stock.symbol);
    setShowDropdown(false);
    setSearchResults([]);
  };

  const handleAnalyze = () => {
    if (!selectedStock) {
      toast.error("Please select a stock first");
      return;
    }

    setIsAnalyzing(true);
    analyzeMutation.mutate({
      symbol: selectedStock.symbol,
      companyName: selectedStock.name,
      investmentHorizon: investmentHorizon[0],
      fundamentalTechnicalRatio: fundamentalTechnicalRatio[0],
      age: age ? parseInt(age) : undefined,
      employmentStatus: employmentStatus || undefined,
      employmentSector: employmentSector || undefined,
    });
  };

  const handleAddToPortfolio = () => {
    if (!selectedStock) return;

    addToPortfolioMutation.mutate({
      symbol: selectedStock.symbol,
      companyName: selectedStock.name,
      investmentHorizon: investmentHorizon[0],
      fundamentalTechnicalRatio: fundamentalTechnicalRatio[0],
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">{APP_TITLE}</h1>
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation('/')}>
              <Home className="mr-2 h-4 w-4" /> Home
            </Button>
            <Button variant="ghost" onClick={() => setLocation('/portfolio')}>
              <PieChart className="mr-2 h-4 w-4" /> Portfolio
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Stock Analysis</h2>

          {/* Stock Search */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Search for a Stock</CardTitle>
              <CardDescription>Enter a stock symbol or company name</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <div className="flex gap-2 items-center">
                  <div className="relative flex-1">
                    <Input
                      placeholder="Type to search stocks (e.g., AAPL, Apple, Microsoft)..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onFocus={() => searchResults.length > 0 && setShowDropdown(true)}
                      className="pr-10"
                    />
                    {isSearching && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-gray-400" />
                    )}
                  </div>
                </div>

                {/* Autocomplete Dropdown */}
                {showDropdown && searchResults.length > 0 && (
                  <div className="absolute z-50 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-80 overflow-y-auto">
                    {searchResults.slice(0, 10).map((stock) => (
                      <div
                        key={stock.symbol}
                        className="p-3 hover:bg-blue-50 cursor-pointer border-b last:border-b-0 transition-colors"
                        onClick={() => handleSelectStock(stock)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="font-semibold text-gray-900">{stock.symbol}</div>
                            <div className="text-sm text-gray-600">{stock.name}</div>
                            <div className="text-xs text-gray-500 mt-1">
                              {stock.region} • {stock.type}
                            </div>
                          </div>
                          <div className="text-xs text-gray-400">
                            Match: {(parseFloat(stock.matchScore) * 100).toFixed(0)}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {searchQuery.length >= 2 && !isSearching && searchResults.length === 0 && (
                  <div className="mt-2 text-sm text-gray-500">
                    No stocks found matching "{searchQuery}"
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {selectedStock && (
            <>
              {/* Investment Parameters */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Investment Parameters</CardTitle>
                  <CardDescription>Customize your analysis preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label>Investment Horizon: {investmentHorizon[0]} months</Label>
                    <Slider
                      value={investmentHorizon}
                      onValueChange={setInvestmentHorizon}
                      min={1}
                      max={60}
                      step={1}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>Short-term (1-6 mo)</span>
                      <span>Medium-term (6-24 mo)</span>
                      <span>Long-term (24+ mo)</span>
                    </div>
                  </div>

                  <div>
                    <Label>Analysis Preference: {fundamentalTechnicalRatio[0]}% Fundamental</Label>
                    <Slider
                      value={fundamentalTechnicalRatio}
                      onValueChange={setFundamentalTechnicalRatio}
                      min={0}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>Pure Technical</span>
                      <span>Balanced</span>
                      <span>Pure Fundamental</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* User Profile */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Your Profile</CardTitle>
                  <CardDescription>Help us personalize your recommendations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Age</Label>
                    <Input
                      type="number"
                      placeholder="e.g., 35"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Employment Status</Label>
                    <Input
                      placeholder="e.g., Employed, Self-employed, Retired"
                      value={employmentStatus}
                      onChange={(e) => setEmploymentStatus(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Employment Sector</Label>
                    <Input
                      placeholder="e.g., Technology, Healthcare, Finance"
                      value={employmentSector}
                      onChange={(e) => setEmploymentSector(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>

              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                size="lg"
                className="w-full mb-6"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <TrendingUp className="mr-2 h-5 w-5" />
                    Analyze Stock
                  </>
                )}
              </Button>

              {/* Analysis Results */}
              {analysisResult && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Analysis Results for {selectedStock.symbol}</span>
                      <span className={`text-lg font-bold ${
                        analysisResult.recommendation === 'BUY' ? 'text-green-600' :
                        analysisResult.recommendation === 'SELL' ? 'text-red-600' :
                        'text-yellow-600'
                      }`}>
                        {analysisResult.recommendation}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Objective Analysis</h3>
                      <div className="prose prose-sm max-w-none">
                        <Streamdown>{analysisResult.analysisText}</Streamdown>
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-2">Personalized Recommendation</h3>
                      <p className="text-gray-700">{analysisResult.personalizedText}</p>
                    </div>

                    <Button
                      onClick={handleAddToPortfolio}
                      variant="outline"
                      className="w-full"
                      disabled={addToPortfolioMutation.isPending}
                    >
                      {addToPortfolioMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Add to Portfolio
                    </Button>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

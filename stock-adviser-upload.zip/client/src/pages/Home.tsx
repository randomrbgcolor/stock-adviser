import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { TrendingUp, PieChart, BarChart3, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-900 mb-4">{APP_TITLE}</h1>
            <p className="text-xl text-gray-600 mb-8">
              AI-Powered Stock Analysis & Portfolio Management
            </p>
            <Button size="lg" onClick={() => window.location.href = getLoginUrl()}>
              Sign In to Get Started
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mt-16">
            <Card>
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Smart Analysis</CardTitle>
                <CardDescription>
                  Get AI-powered stock recommendations based on your investment preferences
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <PieChart className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Portfolio Tracking</CardTitle>
                <CardDescription>
                  Track your investments with real-time data and performance metrics
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <BarChart3 className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>Personalized Insights</CardTitle>
                <CardDescription>
                  Receive tailored advice based on your age, employment, and risk profile
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">{APP_TITLE}</h1>
          <div className="flex gap-4 items-center">
            <span className="text-gray-600">Welcome, {user?.name}</span>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to Your Investment Dashboard
          </h2>
          <p className="text-xl text-gray-600">
            Choose an action to get started
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/analyze')}>
            <CardHeader>
              <TrendingUp className="h-16 w-16 text-blue-600 mb-4" />
              <CardTitle className="text-2xl">Analyze Stocks</CardTitle>
              <CardDescription className="text-base">
                Search for stocks and get AI-powered analysis with personalized recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full" size="lg">
                Start Analysis <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/portfolio')}>
            <CardHeader>
              <PieChart className="h-16 w-16 text-green-600 mb-4" />
              <CardTitle className="text-2xl">My Portfolio</CardTitle>
              <CardDescription className="text-base">
                View and manage your tracked stocks with real-time performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full" size="lg" variant="outline">
                View Portfolio <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

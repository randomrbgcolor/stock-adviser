import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { APP_TITLE, getLoginUrl } from "@/const";
import { Home, TrendingUp, Loader2, Trash2, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Portfolio() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const portfolioQuery = trpc.portfolio.list.useQuery(undefined, {
    refetchInterval: 60000, // Refetch every minute
  });

  const removeMutation = trpc.portfolio.remove.useMutation({
    onSuccess: () => {
      toast.success("Stock removed from portfolio");
      portfolioQuery.refetch();
    },
    onError: (error) => {
      toast.error("Failed to remove stock: " + error.message);
    },
  });

  const handleRemove = (symbol: string) => {
    if (confirm(`Are you sure you want to remove ${symbol} from your portfolio?`)) {
      removeMutation.mutate({ symbol });
    }
  };

  const handleRefresh = () => {
    portfolioQuery.refetch();
    toast.info("Refreshing portfolio data...");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  const formatReturn = (value: string | null | undefined) => {
    if (!value) return "N/A";
    const num = parseFloat(value);
    const isPositive = num >= 0;
    return (
      <span className={isPositive ? "text-green-600" : "text-red-600"}>
        {isPositive ? "+" : ""}{num.toFixed(2)}%
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">{APP_TITLE}</h1>
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation('/')}>
              <Home className="mr-2 h-4 w-4" /> Home
            </Button>
            <Button variant="ghost" onClick={() => setLocation('/analyze')}>
              <TrendingUp className="mr-2 h-4 w-4" /> Analyze
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">My Portfolio</h2>
            <Button onClick={handleRefresh} variant="outline" disabled={portfolioQuery.isRefetching}>
              <RefreshCw className={`mr-2 h-4 w-4 ${portfolioQuery.isRefetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {portfolioQuery.isLoading ? (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
              </CardContent>
            </Card>
          ) : portfolioQuery.data && portfolioQuery.data.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Your Tracked Stocks</CardTitle>
                <CardDescription>
                  Monitor your portfolio performance with real-time data
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Company</TableHead>
                        <TableHead className="text-right">Current Price</TableHead>
                        <TableHead className="text-right">Change</TableHead>
                        <TableHead className="text-right">1M Return</TableHead>
                        <TableHead className="text-right">6M Return</TableHead>
                        <TableHead className="text-right">1Y Return</TableHead>
                        <TableHead className="text-right">YTD Return</TableHead>
                        <TableHead className="text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {portfolioQuery.data.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-semibold">{item.symbol}</TableCell>
                          <TableCell>{item.companyName}</TableCell>
                          <TableCell className="text-right">
                            {item.priceData?.currentPrice ? `$${item.priceData.currentPrice}` : "N/A"}
                          </TableCell>
                          <TableCell className="text-right">
                            {item.priceData?.priceChangePercent || "N/A"}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatReturn(item.priceData?.return1M)}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatReturn(item.priceData?.return6M)}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatReturn(item.priceData?.return1Y)}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatReturn(item.priceData?.returnYTD)}
                          </TableCell>
                          <TableCell className="text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemove(item.symbol)}
                              disabled={removeMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Portfolio Summary</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-gray-600">Total Stocks</div>
                      <div className="text-2xl font-bold">{portfolioQuery.data.length}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Avg 1M Return</div>
                      <div className="text-2xl font-bold">
                        {formatReturn(
                          (
                            portfolioQuery.data.reduce((sum, item) => 
                              sum + parseFloat(item.priceData?.return1M || "0"), 0
                            ) / portfolioQuery.data.length
                          ).toString()
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-600">Avg 6M Return</div>
                      <div className="text-2xl font-bold">
                        {formatReturn(
                          (
                            portfolioQuery.data.reduce((sum, item) => 
                              sum + parseFloat(item.priceData?.return6M || "0"), 0
                            ) / portfolioQuery.data.length
                          ).toString()
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-600">Avg YTD Return</div>
                      <div className="text-2xl font-bold">
                        {formatReturn(
                          (
                            portfolioQuery.data.reduce((sum, item) => 
                              sum + parseFloat(item.priceData?.returnYTD || "0"), 0
                            ) / portfolioQuery.data.length
                          ).toString()
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <TrendingUp className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">
                  Your portfolio is empty
                </h3>
                <p className="text-gray-600 mb-6">
                  Start analyzing stocks and add them to your portfolio to track their performance
                </p>
                <Button onClick={() => setLocation('/analyze')}>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Analyze Stocks
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

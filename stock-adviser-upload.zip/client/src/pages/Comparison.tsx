import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, X, TrendingUp, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'wouter';

interface StockData {
  symbol: string;
  name: string;
  currentPrice: string;
  priceChange: string;
  priceChangePercent: string;
  return1M: string;
  return6M: string;
  return1Y: string;
  returnYTD: string;
}

export default function Comparison() {
  const { user, loading: authLoading } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStocks, setSelectedStocks] = useState<string[]>([]);
  const [stocksData, setStocksData] = useState<Map<string, StockData>>(new Map());

  const searchMutation = trpc.stocks.search.useQuery(
    { keywords: searchQuery },
    { enabled: searchQuery.length >= 2 }
  );

  const utils = trpc.useUtils();
  
  const fetchStockData = async (symbol: string) => {
    try {
      const data = await utils.stocks.quote.fetch({ symbol });
      setStocksData(prev => new Map(prev).set(data.symbol, data as StockData));
    } catch (error) {
      toast.error('Failed to fetch stock data');
      console.error(error);
    }
  };

  const handleAddStock = (symbol: string, name: string) => {
    if (selectedStocks.length >= 5) {
      toast.error('Maximum 5 stocks can be compared');
      return;
    }
    
    if (selectedStocks.includes(symbol)) {
      toast.error('Stock already added');
      return;
    }

    setSelectedStocks([...selectedStocks, symbol]);
    fetchStockData(symbol);
    setSearchQuery('');
  };

  const handleRemoveStock = (symbol: string) => {
    setSelectedStocks(selectedStocks.filter(s => s !== symbol));
    const newData = new Map(stocksData);
    newData.delete(symbol);
    setStocksData(newData);
  };

  const getRecommendationColor = (value: string) => {
    const num = parseFloat(value);
    if (isNaN(num)) return 'text-gray-500';
    if (num > 0) return 'text-green-600';
    if (num < 0) return 'text-red-600';
    return 'text-gray-500';
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please log in to compare stocks</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <h1 className="text-2xl font-bold text-gray-900 cursor-pointer">
              Stock Analysis & Portfolio Advisor
            </h1>
          </Link>
          <div className="flex gap-4">
            <Link href="/">
              <Button variant="ghost">Home</Button>
            </Link>
            <Link href="/analyze">
              <Button variant="ghost">Analyze</Button>
            </Link>
            <Link href="/portfolio">
              <Button variant="ghost">Portfolio</Button>
            </Link>
            <Link href="/comparison">
              <Button variant="default">Compare</Button>
            </Link>
          </div>
          <div className="text-sm text-gray-600">
            Welcome, {user.name}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Stock Comparison</h2>
          <p className="text-gray-600">Compare up to 5 stocks side-by-side</p>
        </div>

        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Add Stocks to Compare</CardTitle>
            <CardDescription>Search and add stocks to your comparison table</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                placeholder="Search for stocks (e.g., AAPL, MSFT, GOOGL)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
            </div>

            {searchMutation.data && searchMutation.data.length > 0 && (
              <div className="mt-4 border rounded-lg divide-y max-h-60 overflow-y-auto">
                {searchMutation.data.slice(0, 10).map((stock) => (
                  <div
                    key={stock.symbol}
                    className="p-3 hover:bg-gray-50 cursor-pointer flex items-center justify-between"
                    onClick={() => handleAddStock(stock.symbol, stock.name)}
                  >
                    <div>
                      <div className="font-semibold">{stock.symbol}</div>
                      <div className="text-sm text-gray-600">{stock.name}</div>
                      <div className="text-xs text-gray-500">{stock.region} • {stock.type}</div>
                    </div>
                    <Plus className="w-5 h-5 text-blue-600" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Selected Stocks */}
        {selectedStocks.length > 0 && (
          <div className="mb-4 flex gap-2 flex-wrap">
            {selectedStocks.map((symbol) => (
              <Badge key={symbol} variant="secondary" className="text-sm px-3 py-1">
                {symbol}
                <button
                  onClick={() => handleRemoveStock(symbol)}
                  className="ml-2 hover:text-red-600"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Comparison Table */}
        {selectedStocks.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Comparison Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Metric</th>
                      {selectedStocks.map((symbol) => (
                        <th key={symbol} className="text-left p-3 font-semibold">
                          {symbol}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">Company Name</td>
                      {selectedStocks.map((symbol) => (
                        <td key={symbol} className="p-3">
                          {stocksData.get(symbol)?.name || <Loader2 className="w-4 h-4 animate-spin" />}
                        </td>
                      ))}
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">Current Price</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className="p-3">
                            {data ? `$${data.currentPrice}` : <Loader2 className="w-4 h-4 animate-spin" />}
                          </td>
                        );
                      })}
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">Price Change</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className={`p-3 ${data ? getRecommendationColor(data.priceChange) : ''}`}>
                            {data ? (
                              <div className="flex items-center gap-1">
                                {parseFloat(data.priceChange) > 0 ? (
                                  <TrendingUp className="w-4 h-4" />
                                ) : (
                                  <TrendingDown className="w-4 h-4" />
                                )}
                                {data.priceChange} ({data.priceChangePercent})
                              </div>
                            ) : (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">1 Month Return</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className={`p-3 ${data ? getRecommendationColor(data.return1M) : ''}`}>
                            {data ? `${data.return1M}%` : <Loader2 className="w-4 h-4 animate-spin" />}
                          </td>
                        );
                      })}
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">6 Month Return</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className={`p-3 ${data ? getRecommendationColor(data.return6M) : ''}`}>
                            {data ? `${data.return6M}%` : <Loader2 className="w-4 h-4 animate-spin" />}
                          </td>
                        );
                      })}
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">1 Year Return</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className={`p-3 ${data ? getRecommendationColor(data.return1Y) : ''}`}>
                            {data ? `${data.return1Y}%` : <Loader2 className="w-4 h-4 animate-spin" />}
                          </td>
                        );
                      })}
                    </tr>
                    <tr className="hover:bg-gray-50">
                      <td className="p-3 font-medium">YTD Return</td>
                      {selectedStocks.map((symbol) => {
                        const data = stocksData.get(symbol);
                        return (
                          <td key={symbol} className={`p-3 ${data ? getRecommendationColor(data.returnYTD) : ''}`}>
                            {data ? `${data.returnYTD}%` : <Loader2 className="w-4 h-4 animate-spin" />}
                          </td>
                        );
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {selectedStocks.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center text-gray-500">
              <p>No stocks selected for comparison</p>
              <p className="text-sm mt-2">Search and add stocks above to get started</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

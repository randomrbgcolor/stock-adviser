import { GoogleGenerativeAI } from '@google/generative-ai';
import OpenAI from 'openai';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

interface AnalysisInput {
  symbol: string;
  companyName: string;
  companyOverview: any;
  currentPrice: string;
  priceChange: string;
  priceChangePercent: string;
  investmentHorizon: number; // in months
  fundamentalTechnicalRatio: number; // 0-100, 0=pure technical, 100=pure fundamental
  age?: number;
  employmentStatus?: string;
  employmentSector?: string;
}

interface AnalysisResult {
  recommendation: 'BUY' | 'SELL' | 'HOLD';
  analysisText: string;
  personalizedText: string;
  provider: 'gemini' | 'openai'; // Track which AI provider was used
}

/**
 * Retry helper with exponential backoff
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 1000
): Promise<T> {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      const isLastRetry = i === maxRetries - 1;
      const isRetryable = error?.message?.includes('503') || error?.message?.includes('overloaded');
      
      if (isLastRetry || !isRetryable) {
        throw error;
      }
      
      const delay = initialDelay * Math.pow(2, i);
      console.log(`Retry ${i + 1}/${maxRetries} after ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw new Error('Max retries exceeded');
}

/**
 * Generate analysis using Gemini
 */
async function generateWithGemini(input: AnalysisInput): Promise<AnalysisResult> {
  const models = ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-flash-latest'];
  
  for (const modelName of models) {
    try {
      console.log(`Attempting analysis with Gemini model: ${modelName}`);
      
      const result = await retryWithBackoff(async () => {
        const model = genAI.getGenerativeModel({ model: modelName });

        // Determine analysis focus based on fundamental vs technical ratio
        const fundamentalWeight = input.fundamentalTechnicalRatio;
        
        let analysisFocus = '';
        if (fundamentalWeight > 70) {
          analysisFocus = 'Focus heavily on fundamental analysis including financial metrics, valuation ratios, earnings, revenue growth, and business fundamentals.';
        } else if (fundamentalWeight > 40) {
          analysisFocus = 'Provide a balanced analysis considering both fundamental metrics (financial health, earnings, valuation) and technical indicators (price trends, momentum).';
        } else {
          analysisFocus = 'Focus heavily on technical analysis including price trends, momentum indicators, chart patterns, and trading volumes.';
        }

        const horizonDescription = input.investmentHorizon <= 6 
          ? 'short-term (less than 6 months)' 
          : input.investmentHorizon <= 24 
            ? 'medium-term (6 months to 2 years)' 
            : 'long-term (more than 2 years)';

        // First prompt: Objective analysis
        const objectivePrompt = `
You are a professional stock analyst. Analyze the following stock and provide an objective BUY, SELL, or HOLD recommendation.

Stock: ${input.symbol} - ${input.companyName}
Current Price: $${input.currentPrice}
Price Change: ${input.priceChange} (${input.priceChangePercent})
Investment Horizon: ${horizonDescription}

Company Overview:
${JSON.stringify(input.companyOverview, null, 2)}

Analysis Instructions:
${analysisFocus}

Provide:
1. A clear recommendation (BUY, SELL, or HOLD)
2. Key reasons supporting your recommendation (3-5 bullet points)
3. Risk factors to consider
4. Price targets or key levels to watch

Format your response as:
RECOMMENDATION: [BUY/SELL/HOLD]

ANALYSIS:
[Your detailed analysis here]
`;
        
        const objectiveResult = await model.generateContent(objectivePrompt);
        const objectiveResponse = objectiveResult.response.text();

        // Extract recommendation
        let recommendation: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
        if (objectiveResponse.includes('RECOMMENDATION: BUY')) {
          recommendation = 'BUY';
        } else if (objectiveResponse.includes('RECOMMENDATION: SELL')) {
          recommendation = 'SELL';
        }

        // Second prompt: Personalized analysis
        const personalizedPrompt = `
Based on the following investor profile, provide personalized advice about whether this stock (${input.symbol}) is suitable for their portfolio.

Investor Profile:
- Age: ${input.age || 'Not specified'}
- Employment Status: ${input.employmentStatus || 'Not specified'}
- Employment Sector: ${input.employmentSector || 'Not specified'}
- Investment Horizon: ${horizonDescription}

Stock Recommendation: ${recommendation}
Stock: ${input.symbol} - ${input.companyName}
Sector: ${input.companyOverview?.Sector || 'Not specified'}

Provide personalized advice considering:
1. Risk tolerance based on age and employment status
2. Sector diversification (if they work in the same sector as the stock)
3. Investment timeline alignment
4. Suitability for their overall portfolio strategy

Keep the response concise (3-4 sentences) and actionable.
`;
        
        const personalizedResult = await model.generateContent(personalizedPrompt);
        const personalizedResponse = personalizedResult.response.text();

        return {
          recommendation,
          analysisText: objectiveResponse.replace(/RECOMMENDATION: (BUY|SELL|HOLD)\n\n/, ''),
          personalizedText: personalizedResponse,
          provider: 'gemini' as const,
        };
      }, 3, 2000);
      
      console.log(`Successfully generated analysis with Gemini model: ${modelName}`);
      return result;
      
    } catch (error: any) {
      console.error(`Failed with Gemini model ${modelName}:`, error.message);
      // Continue to next model
    }
  }
  
  throw new Error('All Gemini models failed');
}

/**
 * Generate analysis using OpenAI (backup)
 */
async function generateWithOpenAI(input: AnalysisInput): Promise<AnalysisResult> {
  console.log('Attempting analysis with OpenAI (backup provider)');
  
  const fundamentalWeight = input.fundamentalTechnicalRatio;
  
  let analysisFocus = '';
  if (fundamentalWeight > 70) {
    analysisFocus = 'Focus heavily on fundamental analysis including financial metrics, valuation ratios, earnings, revenue growth, and business fundamentals.';
  } else if (fundamentalWeight > 40) {
    analysisFocus = 'Provide a balanced analysis considering both fundamental metrics (financial health, earnings, valuation) and technical indicators (price trends, momentum).';
  } else {
    analysisFocus = 'Focus heavily on technical analysis including price trends, momentum indicators, chart patterns, and trading volumes.';
  }

  const horizonDescription = input.investmentHorizon <= 6 
    ? 'short-term (less than 6 months)' 
    : input.investmentHorizon <= 24 
      ? 'medium-term (6 months to 2 years)' 
      : 'long-term (more than 2 years)';

  // Objective analysis
  const objectivePrompt = `
You are a professional stock analyst. Analyze the following stock and provide an objective BUY, SELL, or HOLD recommendation.

Stock: ${input.symbol} - ${input.companyName}
Current Price: $${input.currentPrice}
Price Change: ${input.priceChange} (${input.priceChangePercent})
Investment Horizon: ${horizonDescription}

Company Overview:
${JSON.stringify(input.companyOverview, null, 2)}

Analysis Instructions:
${analysisFocus}

Provide:
1. A clear recommendation (BUY, SELL, or HOLD)
2. Key reasons supporting your recommendation (3-5 bullet points)
3. Risk factors to consider
4. Price targets or key levels to watch

Format your response as:
RECOMMENDATION: [BUY/SELL/HOLD]

ANALYSIS:
[Your detailed analysis here]
`;

  const objectiveResponse = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: 'You are a professional stock analyst.' },
      { role: 'user', content: objectivePrompt }
    ],
    temperature: 0.7,
  });

  const objectiveText = objectiveResponse.choices[0]?.message?.content || '';

  // Extract recommendation
  let recommendation: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
  if (objectiveText.includes('RECOMMENDATION: BUY')) {
    recommendation = 'BUY';
  } else if (objectiveText.includes('RECOMMENDATION: SELL')) {
    recommendation = 'SELL';
  }

  // Personalized analysis
  const personalizedPrompt = `
Based on the following investor profile, provide personalized advice about whether this stock (${input.symbol}) is suitable for their portfolio.

Investor Profile:
- Age: ${input.age || 'Not specified'}
- Employment Status: ${input.employmentStatus || 'Not specified'}
- Employment Sector: ${input.employmentSector || 'Not specified'}
- Investment Horizon: ${horizonDescription}

Stock Recommendation: ${recommendation}
Stock: ${input.symbol} - ${input.companyName}
Sector: ${input.companyOverview?.Sector || 'Not specified'}

Provide personalized advice considering:
1. Risk tolerance based on age and employment status
2. Sector diversification (if they work in the same sector as the stock)
3. Investment timeline alignment
4. Suitability for their overall portfolio strategy

Keep the response concise (3-4 sentences) and actionable.
`;

  const personalizedResponse = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: 'You are a financial advisor.' },
      { role: 'user', content: personalizedPrompt }
    ],
    temperature: 0.7,
  });

  const personalizedText = personalizedResponse.choices[0]?.message?.content || '';

  console.log('Successfully generated analysis with OpenAI');
  
  return {
    recommendation,
    analysisText: objectiveText.replace(/RECOMMENDATION: (BUY|SELL|HOLD)\n\n/, ''),
    personalizedText,
    provider: 'openai' as const,
  };
}

/**
 * Generate AI-powered stock analysis (tries Gemini first, falls back to OpenAI)
 */
export async function generateStockAnalysis(input: AnalysisInput): Promise<AnalysisResult> {
  // Try Gemini first
  try {
    return await generateWithGemini(input);
  } catch (geminiError: any) {
    console.error('All Gemini models failed, falling back to OpenAI:', geminiError.message);
    
    // Fall back to OpenAI
    try {
      return await generateWithOpenAI(input);
    } catch (openaiError: any) {
      console.error('OpenAI also failed:', openaiError.message);
      throw new Error(`Failed to generate AI analysis. Both Gemini and OpenAI providers failed. ${openaiError.message}`);
    }
  }
}

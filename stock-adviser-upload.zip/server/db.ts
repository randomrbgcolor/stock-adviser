import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  userProfiles, 
  portfolioItems, 
  stockAnalyses, 
  stockPriceCache,
  InsertUserProfile,
  InsertPortfolioItem,
  InsertStockAnalysis,
  InsertStockPriceCache
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// User Profile queries
export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertUserProfile(profile: InsertUserProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getUserProfile(profile.userId);
  
  if (existing) {
    await db.update(userProfiles)
      .set({
        age: profile.age,
        employmentStatus: profile.employmentStatus,
        employmentSector: profile.employmentSector,
        updatedAt: new Date(),
      })
      .where(eq(userProfiles.userId, profile.userId));
  } else {
    await db.insert(userProfiles).values(profile);
  }
}

// Portfolio queries
export async function getUserPortfolio(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(portfolioItems)
    .where(eq(portfolioItems.userId, userId))
    .orderBy(desc(portfolioItems.addedAt));
}

export async function addToPortfolio(item: InsertPortfolioItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already exists
  const existing = await db.select().from(portfolioItems)
    .where(and(
      eq(portfolioItems.userId, item.userId),
      eq(portfolioItems.symbol, item.symbol)
    ))
    .limit(1);

  if (existing.length > 0) {
    throw new Error("Stock already in portfolio");
  }

  await db.insert(portfolioItems).values(item);
}

export async function removeFromPortfolio(userId: number, symbol: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(portfolioItems)
    .where(and(
      eq(portfolioItems.userId, userId),
      eq(portfolioItems.symbol, symbol)
    ));
}

// Stock Analysis queries
export async function saveStockAnalysis(analysis: InsertStockAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(stockAnalyses).values(analysis);
}

export async function getRecentAnalysis(userId: number, symbol: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(stockAnalyses)
    .where(and(
      eq(stockAnalyses.userId, userId),
      eq(stockAnalyses.symbol, symbol)
    ))
    .orderBy(desc(stockAnalyses.createdAt))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getAnalysisHistory(userId: number, symbol?: string) {
  const db = await getDb();
  if (!db) return [];

  if (symbol) {
    const result = await db.select().from(stockAnalyses)
      .where(and(
        eq(stockAnalyses.userId, userId),
        eq(stockAnalyses.symbol, symbol)
      ))
      .orderBy(desc(stockAnalyses.createdAt))
      .limit(50);
    return result;
  } else {
    const result = await db.select().from(stockAnalyses)
      .where(eq(stockAnalyses.userId, userId))
      .orderBy(desc(stockAnalyses.createdAt))
      .limit(50);
    return result;
  }
}

export async function getAllUserAnalyses(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db.select().from(stockAnalyses)
    .where(eq(stockAnalyses.userId, userId))
    .orderBy(desc(stockAnalyses.createdAt));

  return result;
}

// Stock Price Cache queries
export async function getStockPriceCache(symbol: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(stockPriceCache)
    .where(eq(stockPriceCache.symbol, symbol))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateStockPriceCache(cache: InsertStockPriceCache) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getStockPriceCache(cache.symbol);

  if (existing) {
    await db.update(stockPriceCache)
      .set({
        currentPrice: cache.currentPrice,
        priceChange: cache.priceChange,
        priceChangePercent: cache.priceChangePercent,
        return1M: cache.return1M,
        return6M: cache.return6M,
        return1Y: cache.return1Y,
        returnYTD: cache.returnYTD,
        lastUpdated: new Date(),
      })
      .where(eq(stockPriceCache.symbol, cache.symbol));
  } else {
    await db.insert(stockPriceCache).values(cache);
  }
}

import axios from 'axios';
import { subMonths, startOfYear } from 'date-fns';

const ALPHA_VANTAGE_API_KEY = process.env.ALPHA_VANTAGE_API_KEY || '';
const BASE_URL = 'https://www.alphavantage.co/query';

interface TimeSeriesData {
  [date: string]: {
    '1. open': string;
    '2. high': string;
    '3. low': string;
    '4. close': string;
    '5. volume': string;
  };
}

interface QuoteData {
  '01. symbol': string;
  '02. open': string;
  '03. high': string;
  '04. low': string;
  '05. price': string;
  '06. volume': string;
  '07. latest trading day': string;
  '08. previous close': string;
  '09. change': string;
  '10. change percent': string;
}

interface SearchResult {
  '1. symbol': string;
  '2. name': string;
  '3. type': string;
  '4. region': string;
  '5. marketOpen': string;
  '6. marketClose': string;
  '7. timezone': string;
  '8. currency': string;
  '9. matchScore': string;
}

/**
 * Search for stock symbols by keyword
 */
export async function searchStockSymbol(keywords: string): Promise<SearchResult[]> {
  try {
    if (!ALPHA_VANTAGE_API_KEY) {
      console.error('ALPHA_VANTAGE_API_KEY is not set');
      throw new Error('Alpha Vantage API key is not configured');
    }

    console.log(`[Stock Search] Searching for: ${keywords}`);
    const response = await axios.get(BASE_URL, {
      params: {
        function: 'SYMBOL_SEARCH',
        keywords,
        apikey: ALPHA_VANTAGE_API_KEY,
      },
      timeout: 10000, // 10 second timeout
    });

    console.log(`[Stock Search] Response status: ${response.status}`);
    
    if (response.data['Note']) {
      console.error('[Stock Search] API rate limit hit:', response.data['Note']);
      throw new Error('API rate limit reached. Please try again in a minute.');
    }

    if (response.data['Error Message']) {
      console.error('[Stock Search] API error:', response.data['Error Message']);
      throw new Error(response.data['Error Message']);
    }

    if (response.data['bestMatches']) {
      console.log(`[Stock Search] Found ${response.data['bestMatches'].length} matches`);
      return response.data['bestMatches'];
    }
    
    console.log('[Stock Search] No matches found');
    return [];
  } catch (error: any) {
    console.error('[Stock Search] Error:', error.message || error);
    if (error.response) {
      console.error('[Stock Search] Response data:', error.response.data);
      console.error('[Stock Search] Response status:', error.response.status);
    }
    throw new Error(error.message || 'Failed to search stock symbol');
  }
}

/**
 * Get current stock quote
 */
export async function getStockQuote(symbol: string): Promise<QuoteData | null> {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        function: 'GLOBAL_QUOTE',
        symbol,
        apikey: ALPHA_VANTAGE_API_KEY,
      },
    });

    if (response.data['Global Quote']) {
      return response.data['Global Quote'];
    }
    return null;
  } catch (error) {
    console.error('Error fetching stock quote:', error);
    throw new Error('Failed to fetch stock quote');
  }
}

/**
 * Get historical daily time series data
 */
export async function getHistoricalData(symbol: string): Promise<TimeSeriesData | null> {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        function: 'TIME_SERIES_DAILY',
        symbol,
        outputsize: 'full',
        apikey: ALPHA_VANTAGE_API_KEY,
      },
    });

    if (response.data['Time Series (Daily)']) {
      return response.data['Time Series (Daily)'];
    }
    return null;
  } catch (error) {
    console.error('Error fetching historical data:', error);
    throw new Error('Failed to fetch historical data');
  }
}

/**
 * Calculate return percentage between two prices
 */
function calculateReturn(currentPrice: number, pastPrice: number): string {
  if (pastPrice === 0) return '0.00';
  const returnPercent = ((currentPrice - pastPrice) / pastPrice) * 100;
  return returnPercent.toFixed(2);
}

/**
 * Get price at a specific date or closest available date
 */
function getPriceAtDate(timeSeries: TimeSeriesData, targetDate: Date): number | null {
  const dates = Object.keys(timeSeries).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  
  // Find the closest date on or before the target date
  for (const date of dates) {
    if (new Date(date) <= targetDate) {
      return parseFloat(timeSeries[date]['4. close']);
    }
  }
  
  return null;
}

/**
 * Calculate stock returns for various time periods
 */
export async function calculateStockReturns(symbol: string) {
  try {
    const quote = await getStockQuote(symbol);
    const timeSeries = await getHistoricalData(symbol);

    if (!quote || !timeSeries) {
      return null;
    }

    const currentPrice = parseFloat(quote['05. price']);
    const now = new Date();

    // Calculate 1 month return
    const oneMonthAgo = subMonths(now, 1);
    const price1M = getPriceAtDate(timeSeries, oneMonthAgo);
    const return1M = price1M ? calculateReturn(currentPrice, price1M) : '0.00';

    // Calculate 6 month return
    const sixMonthsAgo = subMonths(now, 6);
    const price6M = getPriceAtDate(timeSeries, sixMonthsAgo);
    const return6M = price6M ? calculateReturn(currentPrice, price6M) : '0.00';

    // Calculate 1 year return
    const oneYearAgo = subMonths(now, 12);
    const price1Y = getPriceAtDate(timeSeries, oneYearAgo);
    const return1Y = price1Y ? calculateReturn(currentPrice, price1Y) : '0.00';

    // Calculate YTD return
    const yearStart = startOfYear(now);
    const priceYTD = getPriceAtDate(timeSeries, yearStart);
    const returnYTD = priceYTD ? calculateReturn(currentPrice, priceYTD) : '0.00';

    return {
      symbol: quote['01. symbol'],
      currentPrice: quote['05. price'],
      priceChange: quote['09. change'],
      priceChangePercent: quote['10. change percent'],
      return1M,
      return6M,
      return1Y,
      returnYTD,
    };
  } catch (error) {
    console.error('Error calculating stock returns:', error);
    return null;
  }
}

/**
 * Get company overview data
 */
export async function getCompanyOverview(symbol: string) {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        function: 'OVERVIEW',
        symbol,
        apikey: ALPHA_VANTAGE_API_KEY,
      },
    });

    return response.data;
  } catch (error) {
    console.error('Error fetching company overview:', error);
    throw new Error('Failed to fetch company overview');
  }
}

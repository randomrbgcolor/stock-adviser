import { z } from 'zod';
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { 
  getUserProfile, 
  upsertUserProfile, 
  getUserPortfolio, 
  addToPortfolio, 
  removeFromPortfolio,
  saveStockAnalysis,
  getRecentAnalysis,
  getAnalysisHistory,
  getStockPriceCache,
  updateStockPriceCache
} from './db';
import { 
  searchStockSymbol, 
  getStockQuote, 
  calculateStockReturns,
  getCompanyOverview
} from './stockDataService';
import { generateStockAnalysis } from './aiAnalysisService';

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // User Profile
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return await getUserProfile(ctx.user.id);
    }),
    
    upsert: protectedProcedure
      .input(z.object({
        age: z.number().optional(),
        employmentStatus: z.string().optional(),
        employmentSector: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await upsertUserProfile({
          userId: ctx.user.id,
          ...input,
        });
        return { success: true };
      }),
  }),

  // Stock Search and Data
  stocks: router({
    search: protectedProcedure
      .input(z.object({
        keywords: z.string(),
      }))
      .query(async ({ input }) => {
        const results = await searchStockSymbol(input.keywords);
        return results.map(r => ({
          symbol: r['1. symbol'],
          name: r['2. name'],
          type: r['3. type'],
          region: r['4. region'],
          matchScore: r['9. matchScore'],
        }));
      }),

    quote: protectedProcedure
      .input(z.object({
        symbol: z.string(),
      }))
      .query(async ({ input }) => {
        // Check cache first (cache for 5 minutes)
        const cached = await getStockPriceCache(input.symbol);
        if (cached) {
          const cacheAge = Date.now() - new Date(cached.lastUpdated).getTime();
          if (cacheAge < 5 * 60 * 1000) { // 5 minutes
            return cached;
          }
        }

        // Fetch fresh data
        const returns = await calculateStockReturns(input.symbol);
        if (!returns) {
          throw new Error('Failed to fetch stock data');
        }

        // Update cache
        await updateStockPriceCache({
          symbol: returns.symbol,
          currentPrice: returns.currentPrice,
          priceChange: returns.priceChange,
          priceChangePercent: returns.priceChangePercent,
          return1M: returns.return1M,
          return6M: returns.return6M,
          return1Y: returns.return1Y,
          returnYTD: returns.returnYTD,
        });

        return returns;
      }),

    analyze: protectedProcedure
      .input(z.object({
        symbol: z.string(),
        companyName: z.string(),
        investmentHorizon: z.number(),
        fundamentalTechnicalRatio: z.number(),
        age: z.number().optional(),
        employmentStatus: z.string().optional(),
        employmentSector: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Get company overview and current price
        const [overview, quote] = await Promise.all([
          getCompanyOverview(input.symbol),
          getStockQuote(input.symbol),
        ]);

        if (!quote) {
          throw new Error('Failed to fetch stock data');
        }

        // Generate AI analysis
        const analysis = await generateStockAnalysis({
          symbol: input.symbol,
          companyName: input.companyName,
          companyOverview: overview,
          currentPrice: quote['05. price'],
          priceChange: quote['09. change'],
          priceChangePercent: quote['10. change percent'],
          investmentHorizon: input.investmentHorizon,
          fundamentalTechnicalRatio: input.fundamentalTechnicalRatio,
          age: input.age,
          employmentStatus: input.employmentStatus,
          employmentSector: input.employmentSector,
        });

        // Save analysis to database
        await saveStockAnalysis({
          userId: ctx.user.id,
          symbol: input.symbol,
          companyName: input.companyName,
          recommendation: analysis.recommendation,
          analysisText: analysis.analysisText,
          personalizedText: analysis.personalizedText,
          provider: analysis.provider,
          investmentHorizon: input.investmentHorizon,
          fundamentalTechnicalRatio: input.fundamentalTechnicalRatio,
          age: input.age,
          employmentStatus: input.employmentStatus,
          employmentSector: input.employmentSector,
        });

        return analysis;
      }),

    history: protectedProcedure
      .input(z.object({
        symbol: z.string().optional(),
      }))
      .query(async ({ ctx, input }) => {
        const history = await getAnalysisHistory(ctx.user.id, input.symbol);
        return history;
      }),
  }),

  // Portfolio Management
  portfolio: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const items = await getUserPortfolio(ctx.user.id);
      
      // Fetch current data for each stock
      const itemsWithData = await Promise.all(
        items.map(async (item) => {
          try {
            const cached = await getStockPriceCache(item.symbol);
            if (cached) {
              const cacheAge = Date.now() - new Date(cached.lastUpdated).getTime();
              if (cacheAge < 5 * 60 * 1000) { // Use cache if less than 5 minutes old
                return { ...item, priceData: cached };
              }
            }

            // Fetch fresh data
            const returns = await calculateStockReturns(item.symbol);
            if (returns) {
              await updateStockPriceCache({
                symbol: returns.symbol,
                currentPrice: returns.currentPrice,
                priceChange: returns.priceChange,
                priceChangePercent: returns.priceChangePercent,
                return1M: returns.return1M,
                return6M: returns.return6M,
                return1Y: returns.return1Y,
                returnYTD: returns.returnYTD,
              });
              return { ...item, priceData: returns };
            }
            return { ...item, priceData: null };
          } catch (error) {
            console.error(`Error fetching data for ${item.symbol}:`, error);
            return { ...item, priceData: null };
          }
        })
      );

      return itemsWithData;
    }),

    add: protectedProcedure
      .input(z.object({
        symbol: z.string(),
        companyName: z.string(),
        investmentHorizon: z.number(),
        fundamentalTechnicalRatio: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        await addToPortfolio({
          userId: ctx.user.id,
          symbol: input.symbol,
          companyName: input.companyName,
          investmentHorizon: input.investmentHorizon,
          fundamentalTechnicalRatio: input.fundamentalTechnicalRatio,
        });
        return { success: true };
      }),

    remove: protectedProcedure
      .input(z.object({
        symbol: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        await removeFromPortfolio(ctx.user.id, input.symbol);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;

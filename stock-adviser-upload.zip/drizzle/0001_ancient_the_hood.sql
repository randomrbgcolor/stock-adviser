CREATE TABLE `portfolio_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`company_name` varchar(255),
	`added_at` timestamp NOT NULL DEFAULT (now()),
	`investment_horizon` int,
	`fundamental_technical_ratio` int,
	CONSTRAINT `portfolio_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`company_name` varchar(255),
	`recommendation` varchar(20),
	`analysis_text` text,
	`personalized_text` text,
	`investment_horizon` int,
	`fundamental_technical_ratio` int,
	`age` int,
	`employment_status` varchar(100),
	`employment_sector` varchar(100),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_price_cache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`current_price` varchar(20),
	`price_change` varchar(20),
	`price_change_percent` varchar(20),
	`return_1m` varchar(20),
	`return_6m` varchar(20),
	`return_1y` varchar(20),
	`return_ytd` varchar(20),
	`last_updated` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_price_cache_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`age` int,
	`employment_status` varchar(100),
	`employment_sector` varchar(100),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`)
);

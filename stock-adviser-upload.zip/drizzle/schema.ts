import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User profile information for personalized recommendations
 */
export const userProfiles = mysqlTable("user_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  age: int("age"),
  employmentStatus: varchar("employment_status", { length: 100 }),
  employmentSector: varchar("employment_sector", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

/**
 * Portfolio items - stocks added by users for tracking
 */
export const portfolioItems = mysqlTable("portfolio_items", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  companyName: varchar("company_name", { length: 255 }),
  addedAt: timestamp("added_at").defaultNow().notNull(),
  investmentHorizon: int("investment_horizon"), // in months
  fundamentalTechnicalRatio: int("fundamental_technical_ratio"), // 0-100, 0=pure technical, 100=pure fundamental
});

export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertPortfolioItem = typeof portfolioItems.$inferInsert;

/**
 * Stock analysis results - cached AI-generated recommendations
 */
export const stockAnalyses = mysqlTable("stock_analyses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  companyName: varchar("company_name", { length: 255 }),
  recommendation: varchar("recommendation", { length: 20 }), // BUY, SELL, HOLD
  analysisText: text("analysis_text"),
  personalizedText: text("personalized_text"),
  provider: varchar("provider", { length: 20 }), // gemini or openai
  investmentHorizon: int("investment_horizon"),
  fundamentalTechnicalRatio: int("fundamental_technical_ratio"),
  age: int("age"),
  employmentStatus: varchar("employment_status", { length: 100 }),
  employmentSector: varchar("employment_sector", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type StockAnalysis = typeof stockAnalyses.$inferSelect;
export type InsertStockAnalysis = typeof stockAnalyses.$inferInsert;

/**
 * Stock price cache - to avoid excessive API calls
 */
export const stockPriceCache = mysqlTable("stock_price_cache", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  currentPrice: varchar("current_price", { length: 20 }),
  priceChange: varchar("price_change", { length: 20 }),
  priceChangePercent: varchar("price_change_percent", { length: 20 }),
  return1M: varchar("return_1m", { length: 20 }),
  return6M: varchar("return_6m", { length: 20 }),
  return1Y: varchar("return_1y", { length: 20 }),
  returnYTD: varchar("return_ytd", { length: 20 }),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export type StockPriceCache = typeof stockPriceCache.$inferSelect;
export type InsertStockPriceCache = typeof stockPriceCache.$inferInsert;

/**
 * Email notification preferences for users
 */
export const emailPreferences = mysqlTable("email_preferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique(),
  enableDailyDigest: boolean("enable_daily_digest").default(false).notNull(),
  enableWeeklyDigest: boolean("enable_weekly_digest").default(true).notNull(),
  enablePriceAlerts: boolean("enable_price_alerts").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type EmailPreference = typeof emailPreferences.$inferSelect;
export type InsertEmailPreference = typeof emailPreferences.$inferInsert;
